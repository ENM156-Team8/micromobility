# VTApiPlaneraResaWebV4ModelsJourneyDetailsIncludeType

The different kinds of detailed information that could be included in a get journey details request.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


