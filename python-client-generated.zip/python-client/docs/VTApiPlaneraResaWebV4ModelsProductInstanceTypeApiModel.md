# VTApiPlaneraResaWebV4ModelsProductInstanceTypeApiModel

Specifies whether or not the product is dynamically based on the journey route.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


