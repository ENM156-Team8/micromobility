# VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel

Information about a walk, bike or car link between two public transport trip legs.

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transport_mode** | [**VTApiPlaneraResaCoreModelsTransportMode**](VTApiPlaneraResaCoreModelsTransportMode.md) |  | [optional] 
**transport_sub_mode** | [**VTApiPlaneraResaCoreModelsTransportSubMode**](VTApiPlaneraResaCoreModelsTransportSubMode.md) |  | [optional] 
**origin** | [**VTApiPlaneraResaWebV4ModelsJourneysCallApiModel**](VTApiPlaneraResaWebV4ModelsJourneysCallApiModel.md) |  | [optional] 
**destination** | [**VTApiPlaneraResaWebV4ModelsJourneysCallApiModel**](VTApiPlaneraResaWebV4ModelsJourneysCallApiModel.md) |  | [optional] 
**notes** | [**List[VTApiPlaneraResaCoreModelsNote]**](VTApiPlaneraResaCoreModelsNote.md) | An ordered list (most important first) of notes related to the access link. | [optional] 
**distance_in_meters** | **int** | Distance in meters. | [optional] 
**planned_departure_time** | **str** | The planned departure time in RFC 3339 format. | [optional] 
**planned_arrival_time** | **str** | The planned arrival time in RFC 3339 format. | [optional] 
**planned_duration_in_minutes** | **int** | The planned duration in minutes. | [optional] 
**estimated_departure_time** | **str** | The estimated departure time in RFC 3339 format, if available. | [optional] 
**estimated_arrival_time** | **str** | The estimated arrival time in RFC 3339 format, if available. | [optional] 
**estimated_duration_in_minutes** | **int** | The estimated duration in minutes, if available. | [optional] 
**estimated_number_of_steps** | **int** | Number of steps based on the distance and an estimated step length of 0.65 meters. | [optional] 
**link_coordinates** | [**List[VTApiPlaneraResaWebV4ModelsCoordinateApiModel]**](VTApiPlaneraResaWebV4ModelsCoordinateApiModel.md) | The coordinates for the link. | [optional] 
**segments** | [**List[VTApiPlaneraResaWebV4ModelsJourneysLinkSegmentApiModel]**](VTApiPlaneraResaWebV4ModelsJourneysLinkSegmentApiModel.md) | The segments that make up this link. | [optional] 
**journey_leg_index** | **int** | Index of Leg in Journey | [optional] 

## Example

```python
from openapi_client.models.vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model import VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel

# TODO update the JSON string below
json = "{}"
# create an instance of VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel from a JSON string
vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model_instance = VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel.from_json(json)
# print the JSON string representation of the object
print VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel.to_json()

# convert the object into a dict
vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model_dict = vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model_instance.to_dict()
# create an instance of VTApiPlaneraResaWebV4ModelsJourneysConnectionLinkApiModel from a dict
vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model_form_dict = vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model.from_dict(vt_api_planera_resa_web_v4_models_journeys_connection_link_api_model_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


